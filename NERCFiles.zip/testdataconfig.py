import pandas as pd
import nltk
import crffeatureconfig


testdf = pd.read_csv('/Users/bella/PycharmProjects/TMProjectFinNERC/NER-final-test.tsv', sep='\t', header=None, encoding="latin1")

data = testdf.fillna(method="ffill")
data.columns = ["Sentence #", "Token id", "Word", "Tag"]
data = pd.DataFrame.drop(data, columns=["Sentence #", "Token id"])
data = pd.DataFrame.drop(data, index=0)

# running the Stanford POS Tagger from NLTK


# point this path to a utf-8 encoded plain text file in your own file system
text = list(data["Word"].values)
pos_tagged = nltk.pos_tag(text)

# print the list of tuples: (word,word_class)

# create a new column in the dataframe and populate it with the POS tags
data['POS'] = [pos for (word, pos) in pos_tagged]


testdata = data
testdata = crffeatureconfig.add_feat(testdata)



