import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.cm import get_cmap

data = pd.read_csv("/Users/bella/PycharmProjects/TMProjectFinNERC/GMB_dataset.txt", sep="\t", header=None, encoding="latin1")
data = data.fillna(method="ffill")
data.columns = ["index", "Sentence #", "Word", "POS", "Tag"]


data = pd.DataFrame.drop(data, columns=["index"])
data = pd.DataFrame.drop(data, index=0)
head = (data.head(10))
size = (len(data))



#without other bar plot to show distribution of named entities
entity_counts = data.groupby('Tag').size()
entity_counts = entity_counts.drop('O')
plt.barh(entity_counts.index, entity_counts.values, color=[
    '#B0E0E6',
    '#87CEEB',
    '#ADD8E6',
    '#87CEFA',
    '#00BFFF',
    '#1E90FF',
    '#6495ED',
    '#7B68EE',
    '#4169E1',
    '#6A5ACD',
    '#483D8B',
    '#F0F8FF',
    '#E6E6FA',
    '#D8BFD8',
    '#DDA0DD',
    '#EE82EE'
])
plt.xlabel('Frequency')
plt.ylabel('Named Entity')
plt.title('Named Entity Class Distribution in the GMB Corpus')

# Display the graph
plt.show()

words = list(set(data["Word"].values))

n_words = len(words)

import collections
label_counts = collections.Counter(list(data["Tag"].values))
print(label_counts)