import crffeatureconfig
import testdataconfig
import pandas as pd
from seqeval.metrics import  classification_report
import sklearn_crfsuite as sklearn_crfsuite
from sklearn_crfsuite import metrics

import eli5



data = crffeatureconfig.crfdata
data = data.fillna(method="ffill")



xtrain = list(data['Features'][:round(len(data['Features'])*0.8)])
ytrain = list(data['Tag'][:round(len(data['Tag'])*0.8)])


for y in ytrain:
    if len(y) > 1:
        print(y)

xdev = list(data['Features'][round(len(data['Features'])*0.8):])
ydev = list(data['Tag'][round(len(data['Tag'])*0.8):])

testdata= testdataconfig.testdata
testdata = testdata.fillna(method="ffill")

xtest = list(testdata['Features'])
ytest = list(testdata['Tag'])

crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    c1=0.1,
    c2=0.1,
    max_iterations=100,
    all_possible_transitions=False
)

crf.fit(xtrain, ytrain)

y_preddev = crf.predict(xdev)
print(classification_report(ydev, y_preddev))

y_predtest = crf.predict(xtest)
print(classification_report(ytest, y_predtest))

eli5.show_weights(crf, top=30)
