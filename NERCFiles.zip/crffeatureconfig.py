import pandas as pd

def add_feat(data):
    data['Features'] = ''
    for index, row in data.iterrows():
        row['Features'] = [make_feat(row['Word'], row['POS'], index, data)]
        row['Tag'] = [str(row['Tag'])]

    return data



def make_feat(word, pos, index, data):

    features = {'word.isdigit()': word.isdigit(), 'word.istitle()': word.istitle(), 'word.isupper()': word.isupper(),
                'word.lower()': word.lower(), 'word.isalpha()': word.isalpha(), 'bias': 1.0, 'wordlength': len(word)}

    if word[0].isupper():
        features['firstupper'] = True
    else:
        features['firstupper'] = False
    features['postag'] = pos

    if len(word) > 3:
        features['word[-3:]'] = word[-3:]

    if index > 1:
        prevword = data.iloc[index - 1]['Word']
        features['prevword'] = prevword
        postag1 = data.iloc[index - 1]['POS']
        features['BOS'] = False
        features.update({
            '-1:word.lower()': prevword.lower(),
            '-1:word.istitle()':prevword.istitle(),
            '-1:word.isupper()': prevword.isupper(),
            '-1:postag': postag1,
        })
    else:
        features['BOS'] = True

    if index < len(data) - 1:
        features['EOS'] = False
        nextword = data.iloc[index + 1]['Word']
        postag1 = data.iloc[index + 1]['POS']
        features.update({
            '+1:word.lower()': nextword.lower(),
            '+1:word.istitle()': nextword.istitle(),
            '+1:word.isupper()': nextword.isupper(),
            '+1:postag': postag1,
        })
    else:
        features['EOS'] = True

    return features


data = pd.read_csv("/Users/bella/PycharmProjects/TMProjectFinNERC/GMB_dataset.txt", sep="\t", header=None, encoding="latin1")
data = data.fillna(method="ffill")
data.columns = ["index", "Sentence #", "Word", "POS", "Tag"]


data = pd.DataFrame.drop(data, columns=["index"])
data = pd.DataFrame.drop(data, index=0)


crfdata = add_feat(data)

print(type(crfdata['Features'][1]))